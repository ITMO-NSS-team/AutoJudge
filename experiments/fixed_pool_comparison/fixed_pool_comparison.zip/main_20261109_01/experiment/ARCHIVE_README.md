# AutoJudge controlled-6 / fixed-pool experiment

Start with report.md and artifact_audit.json. A smoke run verifies execution/storage; it is not the full benchmark result.

- manifest.json: selected task IDs and input hashes.
- protocol.json / prompts.json: frozen settings and all prompt templates.
- inputs/: complete model-visible traces; references.json: separate scoring labels.
- calls/: exact request bodies and all returned API response fields for every attempt, including invalid outputs, provider IDs, usage and cost. No Authorization headers.
- streams/: original SSE events, including reasoning fragments, usage and keepalives; calls/ identifies assembled streaming responses explicitly.
- results/: generated roles, prepared evidence, all six findings and Overall verdict.
- pipeline_traces/: native AJ message histories, including the actual Overall input.
- source_snapshot/: executed code/config/docs; environment.json: dependency versions.
- dataset_snapshot/: pinned public WW parquet files for independent verification.
- SHA256SUMS.json: checksums of all other included files.

Reasoning is retained if returned by the provider. Provider-internal information that was never returned is not available. API credentials and .env are excluded.
