# Controlled adaptive versus fixed judge-pool comparison

Start with main_20261109_01/experiment/report.md. The pilot and all four initial smoke attempts are retained. Raw inference records, prompts, labels, datasets, frozen protocols, manifests and metrics are unchanged.

Source files use neutral module names and portable launcher paths. Internal planning documents are excluded. Each source_publication.json records the executed and published source hashes. Frozen protocol hashes still describe the original execution; do not rewrite those protocols to resume this run.

SHA256SUMS.json verifies this public package. publication.json identifies administrative changes. The original artifact_audit.json records the audit performed before packaging; use the accompanying verify.py to verify the public package.
