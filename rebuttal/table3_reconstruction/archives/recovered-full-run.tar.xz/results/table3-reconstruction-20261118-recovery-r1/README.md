# Uniform technical recovery, round 1

All 62 original technical failures are included. The original campaign is unchanged. The 286 original successful results are retained, with original hashes and run IDs. Validated intermediate stages are reused only after checking request identity. Every unrecovered stage receives up to three fresh attempts in a new receipt namespace. The same models, prompts, schemas, seeds, generation limits and full 58-trace denominator apply. This is a separate, declared recovery pass, not the original three-attempt protocol. Report both the first-pass results and this recovery policy in the paper.

The report.json accounting covers NEW calls only. combined-accounting.json adds the original campaign exactly once, including uncertain-cost reserves. The aggregate ceiling is $100.
