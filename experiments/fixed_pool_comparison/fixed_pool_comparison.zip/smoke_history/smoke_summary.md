# Two-trace OpenRouter smoke test: completed

Start with **attempt_04/experiment/report.md** and **artifact_audit.json**. Both methods completed both selected traces through the existing AJ pipeline. Offline verification confirmed that every Overall request contains the exact six corresponding judge findings. This small test verifies execution and artifact retention; it does not establish comparative accuracy.

Model for every stage: google/gemini-2.5-flash; provider: Google AI Studio. Same configured prompts, limits and two traces as the previous attempts. The completed attempt uses streamed response retention.

| Method | Calls | Input tokens | Output tokens including reasoning | API-reported cost |
| --- | ---: | ---: | ---: | ---: |
| AutoJudge controlled-six | 16 | 259740 | 19438 | $0.1265170 |
| Strong fixed pool | 16 | 271534 | 16664 | $0.1231202 |

Equal call counts do not establish strict budget matching. Reasoning tokens are included in output tokens and are not added twice.

All earlier transport failures are included in attempts 01–03. Their missing responses and unresolved costs remain flagged in the original ledgers; no zero cost was invented.

Confirmed expense across all attempts: **$0.4213542**. Actual cost remains unknown for **4** earlier requests. Their conservative reservation totals **$0.0872911**; this is not a reported charge.

Each attempt contains source and dataset snapshots, complete model-visible inputs, all received response fields, generated instructions, intermediate findings, native AJ histories, request IDs, usage and costs. Streamed responses are explicitly marked as assembled; their original SSE events are retained under streams/. Information never received from the provider cannot be reconstructed locally.

API credentials, Authorization headers, .env and unrelated account usage are excluded. Each attempt and this bundle have SHA256SUMS.json. No full pilot or main run was started.
