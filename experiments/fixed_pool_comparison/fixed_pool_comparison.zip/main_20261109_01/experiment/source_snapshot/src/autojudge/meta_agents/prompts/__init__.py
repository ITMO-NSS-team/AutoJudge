"""Prompt templates for meta-agents."""

from .graph_prompts import (
    DEFAULT_GRAPH_INSTRUCT
)
from .pool_prompts import (
    # DECENTRALIZED_POOL_INSTRUCT,
    DEFAULT_POOL_INSTRUCT,
    DEFAULT_POOL_INSTRUCT_EXTENDED,
    DEFAULT_POOL_INSTRUCT_EXTENDED_WW,
    DEFAULT_POOL_INSTRUCT_EXTENDED_no_db_tool,
    DEFAULT_POOL_INSTRUCT_EXTENDED_WW_no_db_tool,
    examples_no_tools,
    examples_tools,
)
from .summarization_prompts import (
    STEP_BY_STEP_SUMMARIZATION_PROMPT,
    STEPS_BATCH_SUMMARIZATION_PROMPT,
    TRACE_SUMMARIZATION_PROMPT,
)
from .output_schema_prompts.webarena_bench import output_schema as webarena_output_schema
from .output_schema_prompts.webarena_bench import output_schema_with_summaries as webarena_output_schema_with_summaries
from .output_schema_prompts.webarena_bench import taxonomy as webarena_taxonomy
# from .unified_prompts import UNIFIED_GEN_INSTRUCT

__all__ = [
    "DEFAULT_POOL_INSTRUCT",
    "DEFAULT_POOL_INSTRUCT_EXTENDED",
    "DEFAULT_POOL_INSTRUCT_EXTENDED_no_db_tool",
    "DEFAULT_POOL_INSTRUCT_EXTENDED_WW",
    "DEFAULT_POOL_INSTRUCT_EXTENDED_WW_no_db_tool",
    "DECENTRALIZED_POOL_INSTRUCT",
    "REACT_POOL_INSTRUCT",
    "DEFAULT_GRAPH_INSTRUCT",
    "DECENTRALIZED_GRAPH_INSTRUCT",
    "REACT_GRAPH_INSTRUCT",
    "UNIFIED_GEN_INSTRUCT",
    "TRACE_SUMMARIZATION_PROMPT",
    "STEP_BY_STEP_SUMMARIZATION_PROMPT",
    "STEPS_BATCH_SUMMARIZATION_PROMPT",
    "webarena_taxonomy",
    "webarena_output_schema",
    "webarena_output_schema_with_summaries",
]
